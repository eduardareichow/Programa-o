package finalmenteUmaAula;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Janela extends JFrame {
	
	JPanel tela;
	
	int gy;
	
	
	
	public Janela() {
		
		 tela = new JPanel() {
			
			public void paintComponent(Graphics g) {
				g.setColor(Color.BLACK);
				g.fillRect(0, 0, tela.getWidth(), tela.getHeight());
				
				g.setColor(Color.blue);
				g.fillRect(tela.getWidth()/2, tela.getHeight()/2 - gy, 100, 150);
				
				

				g.setColor(Color.BLACK);
				g.fillRect(0, 0, tela.getWidth(), tela.getHeight());
				
				g.setColor(Color.PINK);
				g.fillRect(tela.getWidth()/2 - 20, tela.getHeight()/2-30, 40, 200);
				g.fillRect(tela.getWidth()/2 - 60, tela.getHeight()/2 + 170 , 120, 40);
				
				g.setColor(Color.RED);
				g.fillRect(tela.getWidth()/2 - 20, tela.getHeight()/2-30, 40, 40);
				
				g.setColor(Color.WHITE);
				g.fillRect(tela.getWidth()/2 - 5, tela.getHeight()/2-30-gy, 10, 30);
				
				
				
			}
			
		};
		setSize(640, 480);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		super.getContentPane().add(tela);
		
		long txAtt = 0;
		
		while(true) {
		if (System.currentTimeMillis() >= txAtt) {
			if (gy > 100) {
				gy = 0;
			} else {
				gy +=5;
			}
			tela.repaint();
			txAtt = System.currentTimeMillis() + 50;
			
		}
		}
	}

}
