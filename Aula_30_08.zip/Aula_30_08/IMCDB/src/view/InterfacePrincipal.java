package view;

import controle.Comando;
import controle.Processador;
import exceptions.CampoVazioException;

import util.TipoOutput;

/**
 *
 * @author mk
 *
 */
public class InterfacePrincipal extends InterfaceBase implements Comando {

    //@Override
    public void executar() {
        String opcao = null;

        do {
            try {

                opcao = input("Escolha a opcao:"
                        + "\n0 - Sair"
                        + "\n1 - Cadastrar Pessoas"
                        + "\n2 - Registrar Atleta"
                        + "\n3 - Cadastrar Exercícios"
                        + "\n4 - Cadastrar Treino");
                
                if (Integer.parseInt(opcao) != 0) {
                    Processador.direcionar(opcao);
                } else {
                    System.exit(0);
                }

            } catch (CampoVazioException cve) {

                output(cve.getMessage() + " Digite novamente", TipoOutput.ALERTA);

            } catch (NullPointerException npe) {
                output("Digite um valore entre 0 e 3", TipoOutput.ERRO);
            }
        } while (opcao == null || !opcao.equals("0"));
    }
}
