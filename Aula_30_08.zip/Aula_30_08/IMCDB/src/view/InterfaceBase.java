/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import exceptions.CampoVazioException;
import javax.swing.*;
import util.TipoOutput;

/**
 *
 * @author 08050449
 */
public class InterfaceBase {

    public static String input(String msg) throws CampoVazioException {
        String s = null;
        s = JOptionPane.showInputDialog(msg);

        if (s.trim().length() == 0) {
            throw new CampoVazioException("Você esqueceu de digitar o nome!");
        }

        return s;
    }

    public static void output(String msg, TipoOutput tipo) {

        switch (tipo) {
            case MENSAGEM:
                JOptionPane.showMessageDialog(null, msg);
                break;
            case ERRO:
                JOptionPane.showMessageDialog(null, msg, "ERRO!", JOptionPane.ERROR_MESSAGE);
                break;
            case ALERTA:
                JOptionPane.showMessageDialog(null, msg, "ATENÇÃO!", JOptionPane.WARNING_MESSAGE);
                break;
        }
    }

    /*
    public static void main(String[] args) {
        InterfaceBase ib = new InterfaceBase();
        String nome = null;

        while (nome == null) {
            try {
                nome = ib.input("Digite o nome:");
                ib.output("Olá " + nome, TipoOutput.MENSAGEM);
            } catch (CampoVazioException cve) {
                ib.output(cve.getMessage(), TipoOutput.ERRO);
            }
        }
    }
*/

}
