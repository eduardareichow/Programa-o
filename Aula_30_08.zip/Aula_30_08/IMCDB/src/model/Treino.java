/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Arrays;

/**
 *
 * @author user
 */
public class Treino {

    private int frequencia, intensidade;
    private Exercicio exercicios[];

    public Treino() {
    }

    public Treino(int frequencia, int intensidade, Exercicio[] exercicios) {
        this.frequencia = frequencia;
        this.intensidade = intensidade;
        this.exercicios = exercicios;
    }

    public int getFrequencia() {
        return frequencia;
    }

    public void setFrequencia(int frequencia) {
        this.frequencia = frequencia;
    }

    public int getIntensidade() {
        return intensidade;
    }

    public void setIntensidade(int intensidade) {
        this.intensidade = intensidade;
    }

    public Exercicio[] getExercicios() {
        return exercicios;
    }

    public void setExercicios(Exercicio[] exercicios) {
        this.exercicios = exercicios;
    }

    public String getExercíciosString() {
        switch (this.exercicios.length) {
            case 0:
                return "Sem exercícios";
            case 1:
                return exercicios[0].getNome();
            default:
                String exerciciosString = null;
                for (Exercicio exercicio : exercicios) {
                    exerciciosString = exercicio.getNome() + "; ";
                }
                return exerciciosString;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + this.frequencia;
        hash = 59 * hash + this.intensidade;
        hash = 59 * hash + Arrays.deepHashCode(this.exercicios);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Treino other = (Treino) obj;
        if (this.frequencia != other.frequencia) {
            return false;
        }
        if (this.intensidade != other.intensidade) {
            return false;
        }
        return Arrays.deepEquals(this.exercicios, other.exercicios);
    }

    @Override
    public String toString() {
        return "Treino:\n"
                + "Frequência: " + getFrequencia() + " Intensidade: " + getIntensidade() + "\n"
                + "Exercícios: " + getExercíciosString();
    }

}
