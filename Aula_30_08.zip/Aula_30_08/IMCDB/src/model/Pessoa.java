package model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import util.ValidaCPF;

/**
 *
 * @author Edson
 */

public class Pessoa {
 
	private String cpf;
	private String nome;
	private String sexo;
	private LocalDate dataNascimento;

        //TOD: trocar por classe
 
        private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        
	public Pessoa(String cpf, String nome, String dataNascimento, String sexo) throws DateTimeParseException, IllegalArgumentException {
            setDataNascimento(dataNascimento);
            setNome(nome);
            setCpf(cpf);
            setSexo(sexo);
	}
        
        public Pessoa(){
        
        }
	
	public String getNome() {
            return nome;
	}
	
	public void setNome(String nome) {
            this.nome=nome;
	}
	
	public String getSexo() {
            return sexo;
	}
	
	public void setSexo(String sexo) throws IllegalArgumentException {
            if(sexo.equalsIgnoreCase("feminino") || sexo.equalsIgnoreCase("fem") || 
               sexo.equalsIgnoreCase("masculino") || sexo.equalsIgnoreCase("masc")){
               this.sexo=sexo;
            }
            else throw new IllegalArgumentException("O sexo deve ser: \n-Masculino\n-Feminino");
	}
	
	public String getDataNascimento() {
		return formatter.format(dataNascimento);
	}
	
	public void setDataNascimento(String data) throws DateTimeParseException {
            try{
                if(data!=null){
                    dataNascimento = LocalDate.parse(data, formatter);  
                }
            } catch(DateTimeParseException pe){
               
                throw new DateTimeParseException("Data inválida", pe.getParsedString(), pe.getErrorIndex());
            }
        }
	
	public String getCpf() {
            return cpf;
	}
	
	public void setCpf(String cpf) throws IllegalArgumentException {
            if(cpf!=null && ValidaCPF.isValido(cpf)){
                this.cpf=cpf;
            } else throw new IllegalArgumentException ("CPF informado não é válido");
	}

    @Override
    
    public String toString() {
        return "Pessoa{" + "cpf=" + cpf + ", nome=" + nome + ", sexo=" + sexo + ", dataNascimento=" + getDataNascimento()+"}";
    }
    
    @Override
    
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + (this.cpf != null ? this.cpf.hashCode() : 0);
        hash = 59 * hash + (this.nome != null ? this.nome.hashCode() : 0);
        return hash;
    }

    @Override
    
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pessoa other = (Pessoa) obj;
        return (this.cpf == null) ? (other.cpf == null) : this.cpf.equals(other.cpf);
    }
  
       
}
    


	
    
    
    
    
 
