/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Objects;

/**
 *
 * @author user
 */
public class Exercicio {

    private String nome, objetivo, instrucoes;

    public Exercicio() {
    }

    public Exercicio(String nome, String objetivo, String instrucoes) {
        this.nome = nome;
        this.objetivo = objetivo;
        this.instrucoes = instrucoes;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public String getInstrucoes() {
        return instrucoes;
    }

    public void setInstrucoes(String instrucoes) {
        this.instrucoes = instrucoes;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.nome);
        hash = 97 * hash + Objects.hashCode(this.objetivo);
        hash = 97 * hash + Objects.hashCode(this.instrucoes);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Exercicio other = (Exercicio) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.objetivo, other.objetivo)) {
            return false;
        }
        return Objects.equals(this.instrucoes, other.instrucoes);
    }

    @Override
    public String toString() {
        return "Exercício: "+getNome()+"\n"
             + "Objetivo: "+getObjetivo()+"\n"
             + "Instruções: "+getInstrucoes();
    }
    
    

}
