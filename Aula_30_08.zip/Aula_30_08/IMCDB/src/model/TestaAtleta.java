package model;

public class TestaAtleta {

    public static void main(String[] args) {

        Atleta at = new Atleta("natação", "joão", "masc", "129.732.380-72", "13/07/1973");

        Exercicio ex1 = new Exercicio("abdominal", "definir musculatura do abdomem", "3 séries de 15");

        Exercicio ex2 = new Exercicio("corrida", "melhorar respiração", "5 km");

        Exercicio ex3 = new Exercicio("agachamento", "definir musculatura da perna", "3 séries de 15");

        Exercicio[] exercicios = {ex1, ex2, ex3};

        Treino treino = new Treino(5, 3, exercicios);

        at.setTreino(treino);

        System.out.println(at);

        Atleta at2 = new Atleta("natação", "joão", "masc", "129.732.380-72", "13/07/1973");

        System.out.println("Atleta 1 == Atleta 2 ?" + at.equals(at2));

        Atleta at3 = new Atleta("natação", "joão", "masc", "298.560.150-90", "13/07/1973");

        System.out.println("Atleta 1 == Atleta 3 ?" + at.equals(at3));

    }

}
