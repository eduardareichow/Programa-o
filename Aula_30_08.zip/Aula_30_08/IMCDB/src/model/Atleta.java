/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 *
 * @author user
 */
public class Atleta extends Pessoa {

    private String modalidade;
    Treino treino;

    
    //construtores
    public Atleta() {
    }

    public Atleta(String modalidade) {
        this.modalidade = modalidade;
    }

    public Atleta(String modalidade, String nome, String sexo, String cpf, String dataNascimento) {
        super(cpf, nome, dataNascimento, sexo);
        this.modalidade = modalidade;
    }

    
    public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }
    
    public void setTreino (Treino treino){
        this.treino = treino;
        
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.modalidade);
        return hash;
    }

    @Override
    public String toString() {
        return "Atleta: "+getNome()+"\n"
             + "CPF: "+getCpf()+"\n"
             + "Modalidade: "+getModalidade()+"\n"
             + "Sexo: "+getSexo()+"\n"
             + "Data de nascimento: "+getDataNascimento();
    }
    
    

}
